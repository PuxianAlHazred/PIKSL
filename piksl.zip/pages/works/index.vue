<template>
  <section>
    <h2 class="title">WORKS</h2>
    <Slider />
  </section>
</template>
